"""
Contract Tests for unison-common

These tests validate the public API contracts of unison-common to ensure
backward compatibility and proper integration with services.
"""

__version__ = "0.1.0"
